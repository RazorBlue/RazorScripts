javascript:

function openRallyPoint() {
    var rallyPoint = findElements('a', 'Commands');
    var delay = 300;
    for (var index = 0; index < rallyPoint.length; index++) {
        (function (index) {
            window.setTimeout(function () {
                var anchor = rallyPoint[index];
                if (anchor.getAttribute("target"))
                    anchor.target = "_blank";
                else
                    anchor.setAttribute("target", "_blank")
                anchor.click();
            }, index * delay);
        }(index));
    }
}

var findElements = function (tag, text) {
    var elements = document.getElementsByTagName(tag);
    var found = [];
    for (var i = 0; i < elements.length; i++) {
        if (elements[i].innerHTML === text) {
            found.push(elements[i]);
        }
    }

    return found;
}

openRallyPoint();