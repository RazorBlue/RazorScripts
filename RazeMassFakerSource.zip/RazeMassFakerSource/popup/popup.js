document.getElementById("delay").value = localStorage.getItem("delay");
document.getElementById("tabs").value = localStorage.getItem("tabs");

document.getElementById("delay").onchange = function () {
	console.log('delay changed');
	if (this.value < 0) this.value = 0;
	if (this.value > 500) this.value = 500;
	localStorage.setItem("delay", this.value);
}

document.getElementById("tabs").onchange = function () {
	console.log('tabs changed');
    if (this.value < 0) this.value = 0;
	if (this.value > 5) this.value = 5;
    console.log(this.value);
	localStorage.setItem("tabs", this.value);
}

document.getElementById("submit").onclick = function () {
    chrome.extension.getBackgroundPage().send();
}

document.getElementById("fill").onclick = function () {
    chrome.extension.getBackgroundPage().fill();
}

document.getElementById("open").onclick = function () {
    chrome.extension.getBackgroundPage().prepare();
}
