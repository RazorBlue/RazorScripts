// Save default values in localStorage on install
chrome.runtime.onInstalled.addListener(function(e) {
	if (!localStorage.getItem("delay")) {
		console.log('setting default');
		localStorage.setItem("delay", 250);
		localStorage.setItem("tabs", 100);
	}
});

// Activate button if command is found
chrome.tabs.onUpdated.addListener(function(tabId, e, tab) {
	chrome.tabs.executeScript(tabId, {code : "if(document.getElementById('troop_confirm_go')||document.getElementById('map_mover')||document.getElementById('target_attack')||document.getElementById('target_support')||document.getElementById('units_table')) { chrome.runtime.sendMessage({show: true}); }"});
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	if(request.show) {
		chrome.pageAction.show(sender.tab.id);
	}
});


// Send commands
function send() {
	var delay = localStorage.getItem("delay");
	var tabnum = localStorage.getItem("tabs");
	var index;

	chrome.tabs.query({currentWindow: true, active: true}, function(tabs) {
		index = tabs[0].index;
	});

	for (i = 0; i < tabnum && i < 100; i++) {
		(function(i) {
			window.setTimeout(function(){
				chrome.tabs.query({currentWindow: true, index: index + i}, function(tabs) {
					var tab = tabs[0];
					if(tab) {
						chrome.tabs.executeScript(tab.id, {code : "var confirm = document.getElementById('troop_confirm_go'); var attack = document.getElementById('target_attack'); if(confirm) confirm.click(); if(attack) attack.click();"});
					}
				});
			}, i * delay);
		}(i));
	}

}

// Fill targets
function fill() {

	var delay = localStorage.getItem("delay");
	var tabnum = localStorage.getItem("tabs");
	var targets = localStorage.getItem("targets");
	var index;

	chrome.tabs.query({currentWindow: true, active: true}, function(tabs) {
		index = tabs[0].index;
	});

	for (i = 0; i < tabnum && i < 100; i++) {
		(function(i) {
			window.setTimeout(function(){
				chrome.tabs.query({currentWindow: true, index: index + i}, function(tabs) {
					var tab = tabs[0];
					if(tab) {
						chrome.tabs.executeScript(tab.id, {file: "fake.js"});
					}
				});
			}, i * (delay+getRndInteger(1, 10)));
		}(i));
	}

}


// Open commands/rally points
function prepare() {
	console.log('inside prepare');
	chrome.tabs.getSelected(null, function(tab){
		chrome.tabs.executeScript(tab.id, {file: "prepare.js"});
	});

}

function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}